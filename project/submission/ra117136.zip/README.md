# Simulação de tracking da dinâmica dos elétrons em um acelerador síncrotron

Gustavo Ciotto Pinton - RA117136
Introdução à Programação Paralela

### Conteúdo

Dois arquivos `pdf` e uma pasta contendos os códigos fontes podem ser encontrados nesta pasta. Os dois arquivos `pdf` referem-se à apresentação e ao relatório

Informações sobre o código-fonte pode ser encontradas no arquivo `README.md` de `src/`
